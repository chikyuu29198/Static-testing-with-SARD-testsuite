package stonesoup.jtree;

/*
# ------------------------------Copyright-------------------------------------
# NOTICE
# 
# This software (or technical data) was produced for the U. S.
# Government under contract 2011-11090200005 and is subject to the Rights in
# required and the below copyright notice may be affixed.
# 
# Copyright (c) 2013 Ponte Technologies. All Rights Reserved.
# -----------------------------Copyright-------------------------------------- 
*/

import java.io.File;
import java.util.Arrays;
import java.util.Comparator;

public abstract class TreePrinter implements ITreePrinter {
	protected int _maxLevel = -1;
	protected Comparator<File> comparator = new Comparator<File>() {
		 
        public int compare(File o1, File o2) {
                return (o1.getName()).compareTo(o2.getName());
        }
    };
	public TreePrinter(int maxLevel) {
		_maxLevel = maxLevel;
	}
	

	protected void printDirectory(File currDir, int level) {
		
		//Print out the name of the current directory
		System.out.println(pad(level) + currDir.getName());
		
		
		if (_maxLevel == -1 || level <= _maxLevel) {

			File[] files = currDir.listFiles();
			Arrays.sort(files, comparator);
			
			for (File file : files ) {
				
				if (file.isDirectory()) {
					//Recursively called the function if this is a sub directory.
					printDirectory(file, level + 1);
				} else {
					System.out.println(pad(level + 1) + file.getName());
				}
			}
		}

	}

	protected String pad(int level) {
		String padding = "|-- ";
		
		//If the level is not the initial level then start it off with a specific set of characters
		if (level == 0) {
			padding = "";
		}
		//Add a bar and tab for each level above the first
		for (int i = 1; i < level && level != 0; i++) {
			padding = "|   " + padding;
		}

		return padding;

	}
	
	public void run(String directory)
	{
		run(new File(directory));
	}
	
	public void run(File directory)
	{
		if(!directory.exists())
		{
			System.out.println("Directory does not exist!");
		}
		else
		{
			printDirectory(directory, 0);
		}
	}

}
